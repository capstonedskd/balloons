# KevinBalloons

A fun single-page web app where balloons bounce and pop when clicked, revealing random animals and playing their sounds.

## Features
- Bouncing colorful balloons
- Balloons pop on click
- Displays animal name and plays matching sound
- Clown horn button for extra fun

## Hosting Instructions
To host this:
1. Create a GitHub repo named `kevinballoons`
2. Upload all files from this zip into the repo
3. Enable GitHub Pages (Settings > Pages > Source = root)
4. Visit your published site!

Enjoy! 🎈
